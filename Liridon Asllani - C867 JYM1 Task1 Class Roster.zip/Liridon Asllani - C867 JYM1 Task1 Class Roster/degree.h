//degree.h
/*Define an enumerated data type DegreeProgram for the degree programs containing the data type values SECURITY, NETWORK, and SOFTWARE.*/


#pragma once

enum degreeProgramList { SECURITY, NETWORK, SOFTWARE };